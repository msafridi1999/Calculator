const result = document.getElementById('result');
const buttons = document.querySelectorAll('#buttons button');

// Add event listeners to all buttons
buttons.forEach(button => {
button.addEventListener('click', () => {
// Handle button click
});
});

// Handle number button clicks
buttons.forEach(button => {
if (button.classList.contains('number')) {
button.addEventListener('click', () => {
// Append the number to the result display
result.value += button.value;
});
}
});

// Handle operator button clicks
buttons.forEach(button => {
if (button.classList.contains('operator')) {
button.addEventListener('click', () => {
// Store the operator
const operator = button.value;

// Evaluate the expression
const expression = result.value + operator;
const result = eval(expression);

// Display the result
result.value = result;
});
}
});

// Handle equals button click
buttons.forEach(button => {
if (button.classList.contains('equals')) {
button.addEventListener('click', () => {
// Evaluate the expression
const expression = result.value;
const result = eval(expression);

// Display the result
result.value = result;
});
}
});

// Handle clear button click
buttons.forEach(button => {
if (button.classList.contains('clear')) {
button.addEventListener('click', () => {
// Clear the result display
result.value = '';
});
}
});
